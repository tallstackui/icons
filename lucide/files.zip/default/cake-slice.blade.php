<!-- @license lucide-static v0.428.0 - ISC -->
<svg {{ $attributes }}
  class="lucide lucide-cake-slice"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="9" cy="7" r="2" />
  <path d="M7.2 7.9 3 11v9c0 .6.4 1 1 1h16c.6 0 1-.4 1-1v-9c0-2-3-6-7-8l-3.6 2.6" />
  <path d="M16 13H3" />
  <path d="M16 17H3" />
</svg>
