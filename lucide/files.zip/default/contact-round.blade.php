<!-- @license lucide-static v0.428.0 - ISC -->
<svg {{ $attributes }}
  class="lucide lucide-contact-round"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M16 18a4 4 0 0 0-8 0" />
  <circle cx="12" cy="11" r="3" />
  <rect width="18" height="18" x="3" y="4" rx="2" />
  <line x1="8" x2="8" y1="2" y2="4" />
  <line x1="16" x2="16" y1="2" y2="4" />
</svg>
